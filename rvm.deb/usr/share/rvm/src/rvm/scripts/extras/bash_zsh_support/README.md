bash_zsh_support
================

support Zsh function hooks for Bash
